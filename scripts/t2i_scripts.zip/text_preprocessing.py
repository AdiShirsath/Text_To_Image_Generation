

import re
import string
from string import digits
from typing import List
import os
# import spacy
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer
from torch.utils.data import Dataset
from PIL import Image
from pathlib import Path
import numpy as np

class EnglishProcessor:
    def __init__(self, arguments):

        self.stop_words = stopwords.words("english")
        self.digit_trans = str.maketrans("", "", digits)
        self.arguments = arguments

        if self.arguments.use_lemmatizer:
            self.spacy_model = spacy.load("en_core_web_sm", disable=["parser", "ner"])
        if self.arguments.use_stemmer:
            self.snowball = SnowballStemmer(language="english")

        if self.arguments.use_stemmer and self.arguments.use_lemmatizer:
            LOGGER.warning(
                "Both stemmer and lemmatizer is passed in arguments, So using lemmatizer as default"
            )
            self.arguments.use_stemmer = False

    def _remove_punctuations(self, text: str, custom_puncts: str = None):
        """
        Removes given punctuations or by default removes string.punctuation
        default - !"#$%&'()*+,-./:;<=>?@[]^_`{|}~
        Args:
            text: string to remove puncts from
            custom_puncts: list of punctuations to remove
        """
        str_trans = str.maketrans("", "", string.punctuation)
        if custom_puncts:
            puncts_to_remove = str(custom_puncts)
            str_trans = str.maketrans("", "", puncts_to_remove)

        return text.translate(str_trans)

    def _remove_digits(self, text):
        return text.translate(self.digit_trans)

    def _remove_urls(self, text):
        text = re.sub(
            r"(?:(?:http|https):\/\/)?([-a-zA-Z0-9.]{2,256}\.[a-z]{2,4})\b(?:\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?",
            "",
            text,
        )
        return text

    def _remove_emails(self, text):
        return re.sub(r"[a-z0-9\.\-+_]+@[a-z0-9\.\-+_]+\.[a-z]+", "", text)

    def _remove_html_tags(self, text):
        return re.sub("<.*?>|&([a-z0-9]+|#[0-9]{1,6}|#x[0-9a-f]{1,6});", "", text)

    def _remove_stopwords(self, text):
        sent = [word for word in text.split() if word not in self.stop_words]
        return " ".join(sent)

    def _sent_lemmatizer(self, text):
        """
        Lemmatizer is text normalization process. It uses spacy to get lemmatized words
        """
        doc = self.spacy_model(text)
        lemmas = [token.lemma_ for token in doc]
        return " ".join(lemmas)

    def _stemmer(self, text):
        """
        Using nltk's snowball stemmer we get stemmed word for given text.

        """
        sent = text.split()
        sent = [self.snowball.stem(word) for word in sent]
        return " ".join(sent)

    def _remove_extraspaces(self, text):
        text = text.split()
        text = " ".join(text)
        return text
        
    def main(self, text: str):
        """
        Depending upon arguments provided to class, this method will preprocess text.
        Args:
            text (str): sentence
        Returns: Cleaned sentence
        """

        if len(text.split()) == 0:
            return text

        text = text.lower()

        if self.arguments.remove_urls:
            text = self._remove_urls(text)

        if self.arguments.remove_digits:
            text = self._remove_digits(text)

        if self.arguments.remove_stopwords:
            text = self._remove_stopwords(text)

        if self.arguments.remove_punctuations:
            text = self._remove_punctuations(text)

        if self.arguments.remove_emails:
            text = self._remove_emails(text)

        if self.arguments.remove_html:
            text = self._remove_html_tags(text)

        if self.arguments.use_lemmatizer:
            text = self._sent_lemmatizer(text)

        if self.arguments.use_stemmer:
            text = self._stemmer(text)

        text = self._remove_extraspaces(text)

        return text


class TextImageDataset(Dataset):
    def __init__(self, text_map, image_dir, transform=None):

        self.text_map = text_map # it has image id as key and caption as values
        self.image_ids = list(text_map.keys())
        self.image_dir = image_dir
        self.transform =  transform
        self.tokenizer = BertTokenizer.from_pretrained("bert-base-uncased")

        # Filter out images that don't exist
        self.valid_image_ids = [
            img_id for img_id in text_map.keys() 
            if os.path.exists(os.path.join(image_dir, f"{img_id}.jpg"))
        ]
        
        print(f"Found {len(self.valid_image_ids)}/{len(text_map)} valid images")

    def __len__(self):
        return len(self.image_ids)

    def __getitem__(self, idx):
        image_id = self.image_ids[idx]
        image_path = Path(f"{self.image_dir}/{image_id}.jpg")
        try:
            image = Image.open(image_path).convert('RGB')
            if self.transform:
                image = self.transform(image)
        except Exception as e:
            # Fallback to a random valid image if current one fails
            print(f"Error loading {image_path}: {str(e)}")
            return self.__getitem__(torch.randint(0, len(self), (1,)).item())
            
        captions = self.text_map[image_id]
        caption = np.random.choice(captions)

        tokens = self.tokenizer(
            caption, padding="max_length",
            truncation= True,
            max_length= 64,
            return_tensors="pt"
        )
        output = {
            'image': image,
            'input_ids': tokens['input_ids'].squeeze(0),
            'attention_mask': tokens['attention_mask'].squeeze(0),
            'caption_text': caption  
        }

        return output






























        



        